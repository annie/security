#ifndef __SHOWQUEUE_H__
#define __SHOWQUEUE_H__

int getName(char *fid, char *arb_name);

#endif
