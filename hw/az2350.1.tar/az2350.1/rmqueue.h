#ifndef __RMQUEUE_H__
#define __RMQUEUE_H__

void getId(char *fid, char *name);

#endif
