#ifndef __ADDQUEUE_H__
#define __ADDQUEUE_H__

unsigned long hash(char *str);
char *setName(char *fn);

#endif
